using System;
using UnityEngine;

namespace GariKotik.StarFall
{
    // Configuration marker only; SDK removes this component from the uploaded avatar.
    // No runtime Update, microphone access, material instancing or shader work.
    [DisallowMultipleComponent]
    [AddComponentMenu("GariKotik/Star Fall Diagnostics")]
    public sealed class StarFallDiagnostics : MonoBehaviour, VRC.SDKBase.IEditorOnly
    {
        [Serializable] public sealed class TagBackup
        {
            public string property;
            public string previous;
        }
        [Serializable] public sealed class MaterialTags
        {
            public Material material;
            public string noGas, noStars, off;
            public bool hybridData;
            public string hybrid;
            public Texture previousHybridTexture;
            public TagBackup[] extraTags = new TagBackup[0];
        }
        [HideInInspector] public Component generatedFury;
        [HideInInspector] public GameObject boundAvatar;
        [HideInInspector] public string generatedFolder;
        [HideInInspector] public MaterialTags[] previousTags = new MaterialTags[0];
    }
}
