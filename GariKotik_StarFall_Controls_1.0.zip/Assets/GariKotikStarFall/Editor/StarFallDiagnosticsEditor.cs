#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;

namespace GariKotik.StarFall
{
    [CustomEditor(typeof(StarFallDiagnostics))]
    public sealed class StarFallDiagnosticsEditor : UnityEditor.Editor
    {
        private static readonly string[] Props = { "_MSFDiagNoGas", "_MSFDiagNoStars", "_MSFDiagOff", "_MSFHybridStars" };
        private static readonly string[] Params = { "SFDiag_NoGas", "SFDiag_NoStars", "SFDiag_Off", "SFDiag_Hybrid" };
        private static readonly string[] Labels = { "No Gas", "No Stars", "Cosmos OFF", "Hybrid Stars" };
        private static readonly string[] QualityProps = {
            "_MSFEffectStrength", "_MSFDepthStrength", "_MSFDepthQuality", "_MSFVolumeDepth",
            "_MSFGasBlend", "_MSFGasQuality", "_MSFGasDepth", "_MSFNaturalStars"
        };
        // Exact same presets as GariKotikStarFallBannerDrawer, not approximations.
        private static readonly float[][] QualityValues = {
            new float[]{1f,1f,0f,0.10f,1f,0f,0.35f,0.25f},
            new float[]{1f,1f,0f,0.18f,1f,1f,0.65f,0.5f},
            new float[]{1f,1f,1f,0.30f,1f,2f,0.90f,0.8f}
        };
        private static string[] ExtraProps {
            get { return QualityProps.Concat(new[]{"_MSFSpatialMotion", "_MSFStarMotionMode", "_MSFGasMotionMode"}).ToArray(); }
        }
        private const string Generated = "Assets/GariKotikStarFall/Generated/Controls";
        private const string TexturePath = "Assets/GariKotikStarFall/Textures/StarFall_HybridStars.png";
        private bool busy;
        private static Texture2D HybridTexture()
        {
            var importer=AssetImporter.GetAtPath(TexturePath) as TextureImporter;
            if (importer==null) throw new InvalidOperationException("Не найдена текстура гибридных звёзд: "+TexturePath);
            // Keep the existing map and platform format, including temporary RGBA32 tests.
            // A tester install must not silently overwrite the texture experiment.
            if (importer.sRGBTexture || importer.alphaIsTransparency || !importer.mipmapEnabled ||
                importer.wrapMode!=TextureWrapMode.Repeat || importer.textureType!=TextureImporterType.Default ||
                importer.alphaSource!=TextureImporterAlphaSource.FromInput)
                throw new InvalidOperationException("Карта звёзд должна быть Default, linear (sRGB off), Alpha Source: Input, Alpha Is Transparency off, mipmaps on, Repeat. Исправить импорт карты и повторить подключение.");
            var texture=AssetDatabase.LoadAssetAtPath<Texture2D>(TexturePath);
            if (texture==null) throw new InvalidOperationException("Не удалось загрузить карту звёзд.");
            return texture;
        }

        public override void OnInspectorGUI()
        {
            var marker = (StarFallDiagnostics)target;
            EditorGUILayout.HelpBox("Star Fall Controls — качество, привязка, движение и диагностика. " +
                "Префаб разместить ПРЯМЫМ ребёнком корня аватара, затем подключить одной кнопкой. " +
                "Создаётся отдельное меню Star Fall Controls через VRCFury; исходные FX/menu/params не редактируются.", MessageType.Info);
            EditorGUILayout.LabelField("VRCFury API", ApiType() == null ? "Не найден — установить/обновить VRCFury" : "Найден");
            EditorGUILayout.LabelField("Состояние", marker.generatedFury == null ? "Не подключено" : "Подключено; после изменений целей переподключить");
            using (new EditorGUI.DisabledScope(busy || EditorApplication.isPlayingOrWillChangePlaymode))
            {
                using (new EditorGUI.DisabledScope(marker.generatedFury != null))
                    if (GUILayout.Button("Подключить кнопки через VRCFury")) Queue(marker, false);
                using (new EditorGUI.DisabledScope(marker.generatedFury == null && marker.previousTags.Length == 0))
                    if (GUILayout.Button("Отключить диагностику")) Queue(marker, true);
            }
            EditorGUILayout.HelpBox("Перед подключением: сохранить сцену, Unlock используемых материалов. " +
                "После подключения: Lock. Кнопки НЕ сохраняются между загрузками и НЕ синхронизируются. " +
                "По умолчанию всё выключено: обычный рабочий вид. No Gas убирает также голосовое свечение газа. " +
                "No Stars убирает звёзды и метеоры. Hybrid Stars включает гибрид вместо оригинала. Cosmos OFF имеет приоритет. Качество/Привязка/Движение: выбор взаимоисключающий внутри группы; выключение выбранного пункта возвращает значения на момент подключения. В мире режимы потока не действуют.", MessageType.Warning);
            EditorGUILayout.LabelField("Диагностические переключатели не являются пресетом качества. Все сравнения — из одной точки, " +
                "с одинаковыми зеркалами/настройками. Рабочее запекание повторять не нужно.", EditorStyles.wordWrappedMiniLabel);
        }
        private void Queue(StarFallDiagnostics marker, bool remove)
        {
            busy = true;
            EditorApplication.delayCall += () => {
                try { if (marker != null) { if (remove) Remove(marker); else Install(marker); } }
                catch (Exception e) { var report = e is TargetInvocationException && e.InnerException != null ? e.InnerException : e;
                    Debug.LogException(report); EditorUtility.DisplayDialog("Star Fall Diagnostics",report.Message,"OK"); }
                finally { busy=false; if (this!=null) Repaint(); }
            };
        }
        private static Type ApiType()
        {
            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                var type=assembly.GetType("com.vrcfury.api.FuryComponents");
                if (type!=null) return type;
            }
            return null;
        }
        private static void RequireMethod(Type type, string name, int count)
        {
            if (type == null || !type.GetMethods(BindingFlags.Public | BindingFlags.Instance).Any(m=>m.Name==name && m.GetParameters().Length==count))
                throw new InvalidOperationException("Неподдерживаемая версия VRCFury API: " + name + ". Обновить VRCFury; FX аватара не изменён.");
        }
        private static void Call(object obj, string name, params object[] args)
        {
            var method=obj.GetType().GetMethods().Single(m=>m.Name==name && m.GetParameters().Length==args.Length);
            method.Invoke(obj,args);
        }
        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            int slash=path.LastIndexOf('/'); EnsureFolder(path.Substring(0,slash));
            AssetDatabase.CreateFolder(path.Substring(0,slash),path.Substring(slash+1));
        }
        private static string TargetPath(Renderer r, Transform root)
        {
            // Explicit relative path from the prefab (a direct child) to the avatar.
            // VRCFury resolves '..' and rewrites it during its build; Unity alone does not.
            return "../" + AnimationUtility.CalculateTransformPath(r.transform,root);
        }
        private static void CheckUniquePath(Renderer r, Transform root)
        {
            for (Transform t=r.transform; t!=root; t=t.parent)
            {
                if (t == null || t.parent == null) throw new InvalidOperationException("Цель вне аватара.");
                if (t.name.Contains("/")) throw new InvalidOperationException("Символ '/' в имени цели: " + t.name);
                int matches=0;
                foreach (Transform sibling in t.parent) if (sibling.name==t.name) matches++;
                if (matches!=1) throw new InvalidOperationException("Неоднозначный путь (одинаковые имена): " + t.name);
            }
            if (r.GetComponents(r.GetType()).Length!=1)
                throw new InvalidOperationException("Несколько Renderer одного типа на объекте: " + r.name);
        }
        private static AnimationClip MakeClip(string folder, string prop, float value, List<Renderer> targets, Transform root, string name)
        {
            var clip = new AnimationClip { name=name, frameRate=60 };
            foreach (var renderer in targets)
                AnimationUtility.SetEditorCurve(clip,
                    EditorCurveBinding.FloatCurve(TargetPath(renderer,root),renderer.GetType(),"material."+prop),
                    AnimationCurve.Constant(0f,1f/60f,value));
            AssetDatabase.CreateAsset(clip,folder+"/"+name+".anim");
            return clip;
        }
        // material.<property> curves affect the renderer's material properties. Do not
        // silently broadcast one slot's captured baseline over a different Star Fall slot.
        private static Dictionary<Renderer, Dictionary<string,float>> CaptureInitialValues(List<Renderer> targets)
        {
            var result=new Dictionary<Renderer, Dictionary<string,float>>();
            foreach (var r in targets)
            {
                var mats=r.sharedMaterials.Where(m=>m!=null && m.HasProperty("_MSFEffectStrength")).ToArray();
                var values=new Dictionary<string,float>();
                foreach (string prop in ExtraProps)
                {
                    float value=mats[0].GetFloat(prop);
                    if (float.IsNaN(value) || float.IsInfinity(value)) throw new InvalidOperationException("Некорректное значение "+prop+" на "+r.name);
                    if (mats.Any(m=>float.IsNaN(m.GetFloat(prop)) || float.IsInfinity(m.GetFloat(prop)) || Mathf.Abs(m.GetFloat(prop)-value)>0.00001f))
                        throw new InvalidOperationException("На Renderer '"+r.name+"' разные значения "+prop+" у материалов Star Fall. Тестер не может безопасно восстановить их одной material-кривой. Согласовать этот параметр между слотами или использовать отдельные Renderer.");
                    values.Add(prop,value);
                }
                result.Add(r,values);
            }
            return result;
        }
        private static AnimationClip MakeChoiceClip(string folder, string name, string[] props, float[] values,
            List<Renderer> targets, Transform root, Dictionary<Renderer, Dictionary<string,float>> initial)
        {
            var clip=new AnimationClip { name=name,frameRate=60 };
            foreach (var renderer in targets)
                for (int i=0;i<props.Length;i++)
                    AnimationUtility.SetEditorCurve(clip,
                        EditorCurveBinding.FloatCurve(TargetPath(renderer,root),renderer.GetType(),"material."+props[i]),
                        AnimationCurve.Constant(0f,1f/60f,values==null ? initial[renderer][props[i]] : values[i]));
            AssetDatabase.CreateAsset(clip,folder+"/"+name+".anim");
            return clip;
        }
        private static void AddChoices(AnimatorController controller, VRCExpressionsMenu parent,
            List<VRCExpressionParameters.Parameter> parameters, FieldInfo localField, string folder,
            string key, string label, string parameterName, string[] props, string[] labels, float[][] values,
            List<Renderer> targets, Transform root, Dictionary<Renderer, Dictionary<string,float>> initial)
        {
            if (labels.Length!=values.Length || values.Any(v=>v.Length!=props.Length))
                throw new InvalidOperationException("Некорректная схема группы "+key);
            controller.AddParameter(parameterName,AnimatorControllerParameterType.Int);
            controller.AddLayer("SF Controls "+key);
            var layers=controller.layers; layers[layers.Length-1].defaultWeight=1f; controller.layers=layers;
            var sm=controller.layers[controller.layers.Length-1].stateMachine;
            var menu=ScriptableObject.CreateInstance<VRCExpressionsMenu>(); menu.name=label;
            for (int i=0;i<=values.Length;i++)
            {
                var state=sm.AddState(i==0 ? "Installed values" : labels[i-1]);
                state.writeDefaultValues=false;
                state.motion=MakeChoiceClip(folder,"Choice_"+key+"_"+i,props,i==0 ? null : values[i-1],targets,root,initial);
                if (i==0) sm.defaultState=state;
                var transition=sm.AddAnyStateTransition(state);
                transition.hasExitTime=false; transition.duration=0f; transition.canTransitionToSelf=false;
                transition.AddCondition(AnimatorConditionMode.Equals,i,parameterName);
                if (i>0) menu.controls.Add(new VRCExpressionsMenu.Control {name=labels[i-1],
                    type=VRCExpressionsMenu.Control.ControlType.Toggle,
                    parameter=new VRCExpressionsMenu.Control.Parameter {name=parameterName},value=i});
            }
            var param=new VRCExpressionParameters.Parameter {name=parameterName,valueType=VRCExpressionParameters.ValueType.Int,defaultValue=0f,saved=false};
            localField.SetValue(param,false); parameters.Add(param);
            AssetDatabase.CreateAsset(menu,folder+"/Menu_"+key+".asset");
            parent.controls.Add(new VRCExpressionsMenu.Control {name=label,type=VRCExpressionsMenu.Control.ControlType.SubMenu,subMenu=menu});
        }
        private static void PersistControllerObjects(AnimatorController controller)
        {
            foreach (var layer in controller.layers)
            {
                var sm=layer.stateMachine;
                if (!AssetDatabase.Contains(sm)) AssetDatabase.AddObjectToAsset(sm,controller);
                foreach (var transition in sm.anyStateTransitions)
                    if (!AssetDatabase.Contains(transition)) AssetDatabase.AddObjectToAsset(transition,controller);
                foreach (var child in sm.states)
                {
                    if (!AssetDatabase.Contains(child.state)) AssetDatabase.AddObjectToAsset(child.state,controller);
                    foreach (var transition in child.state.transitions)
                        if (!AssetDatabase.Contains(transition)) AssetDatabase.AddObjectToAsset(transition,controller);
                }
            }
        }
        private static void Install(StarFallDiagnostics marker)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorUtility.IsPersistent(marker) ||
                UnityEditor.SceneManagement.PrefabStageUtility.GetCurrentPrefabStage()!=null)
                throw new InvalidOperationException("Подключать в обычной сцене вне Play/Prefab Mode.");
            var avatar = marker.GetComponentInParent<VRCAvatarDescriptor>();
            if (avatar==null || marker.transform.parent!=avatar.transform)
                throw new InvalidOperationException("Поставить префаб ПРЯМО под корень аватара с VRC Avatar Descriptor.");
            if (!avatar.gameObject.scene.IsValid() || string.IsNullOrEmpty(avatar.gameObject.scene.path))
                throw new InvalidOperationException("Сначала сохранить сцену.");
            if (marker.generatedFury!=null) throw new InvalidOperationException("Диагностика уже подключена.");
            if (avatar.GetComponentsInChildren<StarFallDiagnostics>(true).Any(m=>m!=marker))
                throw new InvalidOperationException("Оставить только один диагностический префаб на аватаре.");
            var api=ApiType(); var factory=api==null ? null : api.GetMethod("CreateFullController",new[]{typeof(GameObject)});
            if (factory==null) throw new InvalidOperationException("Не найден public API VRCFury. Установить/обновить VRCFury.");
            RequireMethod(factory.ReturnType,"AddController",2); RequireMethod(factory.ReturnType,"AddMenu",2); RequireMethod(factory.ReturnType,"AddParams",1);
            // Modern SDK supports local-only menu parameters. Never silently sync diagnostic switches.
            var localField=typeof(VRCExpressionParameters.Parameter).GetField("networkSynced");
            if (localField==null) throw new InvalidOperationException("Обновить VRChat SDK: нет networkSynced для локальной диагностики.");
            var texture=HybridTexture();
            var materials=new HashSet<Material>(); var targets=new List<Renderer>();
            foreach (var renderer in avatar.GetComponentsInChildren<Renderer>(true))
            {
                if (!(renderer is SkinnedMeshRenderer) && !(renderer is MeshRenderer)) continue;
                bool use=false;
                foreach (var material in renderer.sharedMaterials)
                {
                    if (material==null || !material.HasProperty("_MSFEffectStrength")) continue;
                    if (material.HasProperty("_ShaderOptimizerEnabled") && material.GetFloat("_ShaderOptimizerEnabled")>0.5f)
                        throw new InvalidOperationException("Сначала Unlock: " + material.name);
                    foreach (var prop in Props.Concat(ExtraProps)) if (!material.HasProperty(prop))
                        throw new InvalidOperationException("Не хватает свойства тестера в материале: " + material.name + ". Обновить шейдер и выполнить Unlock.");
                    if (!material.HasProperty("_MSFHybridStarMap"))
                        throw new InvalidOperationException("Нет свойства карты гибридных звёзд: " + material.name);
                    materials.Add(material); use=true;
                }
                if (use) { CheckUniquePath(renderer,avatar.transform); targets.Add(renderer); }
            }
            if (targets.Count==0) throw new InvalidOperationException("Материалы Star Fall не найдены.");
            var initial=CaptureInitialValues(targets);
            if (!EditorUtility.DisplayDialog("Star Fall Diagnostics", "Подключить локальное меню управления к " + targets.Count +
                " Renderer? Будут добавлены теги Animated для диагностических и переключаемых свойств в " + materials.Count +
                " материалах. Назначается текущая карта гибридных звёзд. Значения качества и движения сохраняются в начальные клипы. Меши, Voice Link и существующие FX/menu/params не редактируются. Нужна резервная копия.","Подключить","Отмена")) return;
            string folder=null; int group=-1; var before=marker.GetComponents<Component>();
            try
            {
                Undo.IncrementCurrentGroup(); group=Undo.GetCurrentGroup(); Undo.SetCurrentGroupName("Star Fall diagnostics install");
                EnsureFolder(Generated); folder=Generated+"/Controls_"+Guid.NewGuid().ToString("N").Substring(0,10); EnsureFolder(folder);
                var controller=AnimatorController.CreateAnimatorControllerAtPath(folder+"/Diagnostics_FX.controller");
                var menu=ScriptableObject.CreateInstance<VRCExpressionsMenu>(); menu.name="Star Fall Controls";
                var parameters=ScriptableObject.CreateInstance<VRCExpressionParameters>(); parameters.name="Star Fall Diagnostics Parameters";
                var expressionParams=new List<VRCExpressionParameters.Parameter>();
                for (int i=0;i<Props.Length;i++)
                {
                    controller.AddParameter(Params[i],AnimatorControllerParameterType.Bool);
                    if (i>0) controller.AddLayer("SF Diagnostic " + Labels[i]);
                    var layers=controller.layers; layers[i].name="SF Diagnostic " + Labels[i]; layers[i].defaultWeight=1f; controller.layers=layers;
                    var sm=controller.layers[i].stateMachine;
                    var off=sm.AddState("Normal"); var on=sm.AddState("Skip");
                    off.writeDefaultValues=false; on.writeDefaultValues=false;
                    off.motion=MakeClip(folder,Props[i],0f,targets,avatar.transform,"Normal_"+i);
                    on.motion=MakeClip(folder,Props[i],1f,targets,avatar.transform,"Skip_"+i);
                    sm.defaultState=off;
                    var enable=off.AddTransition(on); enable.hasExitTime=false; enable.duration=0f;
                    enable.AddCondition(AnimatorConditionMode.If,0f,Params[i]);
                    var disable=on.AddTransition(off); disable.hasExitTime=false; disable.duration=0f;
                    disable.AddCondition(AnimatorConditionMode.IfNot,0f,Params[i]);
                    var parameter=new VRCExpressionParameters.Parameter {name=Params[i], valueType=VRCExpressionParameters.ValueType.Bool, defaultValue=0f, saved=false};
                    localField.SetValue(parameter,false); expressionParams.Add(parameter);
                    menu.controls.Add(new VRCExpressionsMenu.Control { name=Labels[i],type=VRCExpressionsMenu.Control.ControlType.Toggle,
                        parameter=new VRCExpressionsMenu.Control.Parameter { name=Params[i] },value=1f });
                }
                AddChoices(controller, menu, expressionParams, localField, folder, "Quality", "Качество", "SFDiag_Quality",
                    QualityProps, new[]{"Оптимизированный", "Базовый", "Full"}, QualityValues, targets, avatar.transform, initial);
                AddChoices(controller, menu, expressionParams, localField, folder, "Anchor", "Привязка", "SFDiag_Anchor",
                    new[]{"_MSFSpatialMotion"}, new[]{"По времени", "К миру"},
                    new[]{new[]{0f},new[]{1f}}, targets, avatar.transform, initial);
                var motionMenu=ScriptableObject.CreateInstance<VRCExpressionsMenu>(); motionMenu.name="Движение";
                AddChoices(controller, motionMenu, expressionParams, localField, folder, "Stars", "Звёзды", "SFDiag_StarMode",
                    new[]{"_MSFStarMotionMode"}, new[]{"Прежний", "Поток", "Смешанный"},
                    new[]{new[]{0f},new[]{1f},new[]{2f}}, targets, avatar.transform, initial);
                AddChoices(controller, motionMenu, expressionParams, localField, folder, "Gas", "Газ", "SFDiag_GasMode",
                    new[]{"_MSFGasMotionMode"}, new[]{"Прежний", "Поток", "Смешанный"},
                    new[]{new[]{0f},new[]{1f},new[]{2f}}, targets, avatar.transform, initial);
                AssetDatabase.CreateAsset(motionMenu,folder+"/Menu_Motion.asset");
                menu.controls.Add(new VRCExpressionsMenu.Control {name="Движение", type=VRCExpressionsMenu.Control.ControlType.SubMenu,subMenu=motionMenu});
                parameters.parameters=expressionParams.ToArray();
                AssetDatabase.CreateAsset(menu,folder+"/Menu.asset"); AssetDatabase.CreateAsset(parameters,folder+"/Parameters.asset");
                PersistControllerObjects(controller); EditorUtility.SetDirty(controller); EditorUtility.SetDirty(menu); EditorUtility.SetDirty(parameters);
                AssetDatabase.SaveAssets();
                object component=factory.Invoke(null,new object[]{marker.gameObject});
                var added=marker.GetComponents<Component>().Where(c=>c!=null && !before.Contains(c)).ToArray();
                if (added.Length!=1) throw new InvalidOperationException("Неожиданный результат CreateFullController; установка отменена.");
                Undo.RegisterCreatedObjectUndo(added[0],"Add diagnostics VRCFury");
                Call(component,"AddController",controller,VRCAvatarDescriptor.AnimLayerType.FX);
                Call(component,"AddMenu",menu,"Star Fall Controls"); Call(component,"AddParams",parameters);
                EditorUtility.SetDirty(added[0]);
                PrefabUtility.RecordPrefabInstancePropertyModifications(added[0]);
                Undo.RecordObject(marker,"Diagnostics settings");
                marker.previousTags=materials.Select(m=>new StarFallDiagnostics.MaterialTags { material=m,
                    noGas=m.GetTag(Props[0]+"Animated",false,""), noStars=m.GetTag(Props[1]+"Animated",false,""),off=m.GetTag(Props[2]+"Animated",false,""),
                    hybridData=true, hybrid=m.GetTag(Props[3]+"Animated",false,""),previousHybridTexture=m.GetTexture("_MSFHybridStarMap"),
                    extraTags=ExtraProps.Select(p=>new StarFallDiagnostics.TagBackup {property=p,previous=m.GetTag(p+"Animated",false,"")}).ToArray() }).ToArray();
                foreach (var material in materials)
                {
                    Undo.RecordObject(material,"Animated diagnostic properties");
                    foreach (var prop in Props.Concat(ExtraProps)) material.SetOverrideTag(prop+"Animated","1");
                    material.SetTexture("_MSFHybridStarMap",texture);
                    EditorUtility.SetDirty(material);
                }
                marker.generatedFury=added[0]; marker.boundAvatar=avatar.gameObject; marker.generatedFolder=folder;
                EditorUtility.SetDirty(marker); PrefabUtility.RecordPrefabInstancePropertyModifications(marker);
                AssetDatabase.SaveAssets(); Undo.CollapseUndoOperations(group);
                EditorUtility.DisplayDialog("Star Fall Diagnostics", "Подключено. Выполнить Lock материалов и обычную загрузку. Меню: Star Fall Controls. " +
                    "Для исходных значений отключить четыре диагностические кнопки и выбранные пункты в новых группах. Hybrid Stars включает гибрид. Значения пресетов точно совпадают с инспектором шейдера. Перезапекание мешей не нужно. Сохранить сцену.","OK");
            }
            catch
            {
                if (group>=0) Undo.RevertAllDownToGroup(group);
                foreach (var c in marker.GetComponents<Component>().Where(c=>c!=null && !before.Contains(c)).ToArray()) UnityEngine.Object.DestroyImmediate(c);
                if (folder!=null) AssetDatabase.DeleteAsset(folder);
                throw;
            }
        }
        private static void Remove(StarFallDiagnostics marker)
        {
            foreach (var entry in marker.previousTags)
                if (entry.material!=null && entry.material.HasProperty("_ShaderOptimizerEnabled") && entry.material.GetFloat("_ShaderOptimizerEnabled")>0.5f)
                    throw new InvalidOperationException("Сначала Unlock: " + entry.material.name);
            Undo.IncrementCurrentGroup(); int group=Undo.GetCurrentGroup(); Undo.SetCurrentGroupName("Remove Star Fall diagnostics");
            if (marker.generatedFury!=null) Undo.DestroyObjectImmediate(marker.generatedFury);
            foreach (var entry in marker.previousTags)
            {
                if (entry.material==null) continue;
                Undo.RecordObject(entry.material,"Restore diagnostic tags");
                string[] old={entry.noGas,entry.noStars,entry.off,entry.hybrid};
                for (int i=0;i<(entry.hybridData ? Props.Length : 3);i++)
                    if (entry.material.GetTag(Props[i]+"Animated",false,"")=="1") entry.material.SetOverrideTag(Props[i]+"Animated",old[i]??"");
                if (entry.extraTags!=null) foreach (var tag in entry.extraTags)
                    if (tag!=null && !string.IsNullOrEmpty(tag.property) &&
                        entry.material.GetTag(tag.property+"Animated",false,"")=="1")
                        entry.material.SetOverrideTag(tag.property+"Animated",tag.previous??"");
                if (entry.hybridData && entry.material.HasProperty("_MSFHybridStarMap") &&
                    entry.material.GetTexture("_MSFHybridStarMap")==AssetDatabase.LoadAssetAtPath<Texture2D>(TexturePath))
                    entry.material.SetTexture("_MSFHybridStarMap",entry.previousHybridTexture);
                EditorUtility.SetDirty(entry.material);
            }
            Undo.RecordObject(marker,"Clear diagnostics settings");
            marker.generatedFury=null; marker.boundAvatar=null; marker.previousTags=new StarFallDiagnostics.MaterialTags[0];
            EditorUtility.SetDirty(marker); PrefabUtility.RecordPrefabInstancePropertyModifications(marker);
            AssetDatabase.SaveAssets(); Undo.CollapseUndoOperations(group);
            EditorUtility.DisplayDialog("Star Fall Diagnostics","Отключено. Префаб можно удалить, затем Lock материалов. Созданные ассеты оставлены для Undo. Сохранить сцену.","OK");
        }
    }
}
#endif
